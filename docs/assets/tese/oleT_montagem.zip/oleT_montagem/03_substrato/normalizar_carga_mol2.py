#!/usr/bin/env python3
"""Leva a soma das cargas de um mol2 exatamente ao inteiro esperado.

O antechamber grava cargas AM1-BCC com residuo de arredondamento (ex.:
-0.999 em vez de -1.000). O residuo e dividido igualmente entre todos os
atomos; o que sobra do arredondamento a 6 casas vai para o atomo de maior
|carga|. Correcao tipica: ~1e-5 e por atomo.

Uso: python3 normalizar_carga_mol2.py C14.mol2 -1
"""
import sys
from pathlib import Path

arq, alvo = Path(sys.argv[1]), int(sys.argv[2])
linhas = arq.read_text().splitlines()
ini = linhas.index("@<TRIPOS>ATOM") + 1
fim = next(i for i in range(ini, len(linhas)) if linhas[i].startswith("@<TRIPOS>"))
cargas = [float(linhas[i].split()[8]) for i in range(ini, fim)]
antes = sum(cargas)
delta = (alvo - antes) / len(cargas)
novas = [round(q + delta, 6) for q in cargas]
k = max(range(len(novas)), key=lambda i: abs(novas[i]))
novas[k] = round(novas[k] + (alvo - sum(novas)), 6)
for n, i in enumerate(range(ini, fim)):
    c = linhas[i].split()
    linhas[i] = (f"{int(c[0]):7d} {c[1]:<8s}{float(c[2]):11.4f}{float(c[3]):11.4f}"
                 f"{float(c[4]):11.4f} {c[5]:<6s}{int(c[6]):5d} {c[7]:<8s}{novas[n]:10.6f}")
arq.write_text("\n".join(linhas) + "\n")
print(f"{arq.name}: soma {antes:+.6f} -> {sum(novas):+.6f} "
      f"(correcao {delta:+.2e} e por atomo, {len(novas)} atomos)")
