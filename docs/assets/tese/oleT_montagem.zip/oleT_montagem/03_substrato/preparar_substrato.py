#!/usr/bin/env python3
"""Gera o carboxilato Cn a partir da pose cristalografica do C20 (DCR) do 4L40.

Uso:  python3 preparar_substrato.py 4L40.pdb 14      -> C14_pose.sdf

- Le os atomos pesados do ligante (resname DCR por padrao) do PDB.
- Acha o carbono carboxilico (C ligado a dois O) e percorre a cadeia
  pelas distancias C-C; mantem os n primeiros carbonos. A cabeca
  carboxilato fica exatamente na posicao cristalografica (ponte com a
  Arg245); so a cauda e encurtada.
- Atribui ordens de ligacao pelo SMILES do carboxilato e adiciona os H
  com coordenadas (RDKit). Carga formal -1 no O desprotonado.
Nada e minimizado aqui: a relaxacao acontece na escada de EM do GROMACS.
"""
import sys
import numpy as np
from rdkit import Chem
from rdkit.Chem import AllChem

pdb, n = sys.argv[1], int(sys.argv[2])
resname = sys.argv[3] if len(sys.argv) > 3 else "DCR"
if not 2 <= n <= 20:
    sys.exit("n deve estar entre 2 e 20")

atomos = []
for l in open(pdb):
    if l.startswith(("ATOM", "HETATM")) and l[17:20].strip() == resname:
        el = (l[76:78].strip() or l[12:16].strip()[0]).upper()
        if el != "H" and l[16] in (" ", "A"):
            atomos.append((l[12:16].strip(), el,
                           np.array([float(l[30:38]), float(l[38:46]), float(l[46:54])])))
if not atomos:
    sys.exit(f"Nenhum atomo {resname} em {pdb}")

C = [a for a in atomos if a[1] == "C"]
O = [a for a in atomos if a[1] == "O"]
lig = lambda a, b: np.linalg.norm(a[2] - b[2]) < 1.75
carbox = [c for c in C if sum(lig(c, o) for o in O) == 2]
if len(carbox) != 1:
    sys.exit(f"Esperado 1 carbono carboxilico, achei {len(carbox)}")

cadeia, anterior = [carbox[0]], None
while len(cadeia) < n:
    viz = [c for c in C if lig(cadeia[-1], c) and c is not anterior and c not in cadeia]
    if len(viz) != 1:
        sys.exit(f"Cadeia ambigua ou curta demais apos {len(cadeia)} carbonos")
    anterior = cadeia[-1]
    cadeia.append(viz[0])
oxig = [o for o in O if lig(carbox[0], o)]

# Molecula de atomos pesados na ordem: O, O, C1..Cn
rw = Chem.RWMol()
conf = Chem.Conformer(n + 2)
for i, a in enumerate(oxig + cadeia):
    idx = rw.AddAtom(Chem.Atom(a[1]))
    conf.SetAtomPosition(idx, a[2].tolist())
rw.AddBond(2, 0, Chem.BondType.SINGLE)
rw.AddBond(2, 1, Chem.BondType.SINGLE)
for i in range(2, n + 1):
    rw.AddBond(i, i + 1, Chem.BondType.SINGLE)
mol = rw.GetMol()
mol.AddConformer(conf, assignId=True)

molde = Chem.MolFromSmiles("[O-]C(=O)" + "C" * (n - 1))
mol = AllChem.AssignBondOrdersFromTemplate(molde, mol)
Chem.SanitizeMol(mol)
molH = Chem.AddHs(mol, addCoords=True)
q = Chem.GetFormalCharge(molH)
assert q == -1, q
nome = f"C{n}"
molH.SetProp("_Name", nome)
Chem.MolToMolFile(molH, f"{nome}_pose.sdf")
print(f"{nome}: {molH.GetNumAtoms()} atomos, carga formal {q:+d} -> {nome}_pose.sdf")
print(f"  C-carboxilico em {np.round(carbox[0][2], 3)} (identico ao cristal)")
