#!/usr/bin/env bash
# Pose (do C20 do 4L40) + GAFF2/AM1-BCC para cada comprimento de cadeia.
# Uso: bash parametrizar_substratos.sh 4L40.pdb 8 10 12 14 16 18 20
# Saida por cadeia: Cn_pose.sdf, Cn.mol2 (carga exata -1), Cn.frcmod,
#                   Cn_antechamber.log, Cn_sqm.out
set -uo pipefail
PDB=$1; shift
AQUI=$(cd "$(dirname "$0")" && pwd)

# 1. Ferramentas: antechamber/parmchk2/sqm vem do AmberTools do acpype (Passo 0)
for c in antechamber parmchk2 sqm python3; do
  if ! command -v "$c" > /dev/null; then
    echo "ERRO: '$c' nao encontrado no PATH."
    echo "Rode o Passo 0 neste terminal:"
    echo '  A=$(python3 -c "import acpype,os;print(os.path.dirname(acpype.__file__))")'
    echo '  export AMBERHOME=$A/amber_linux  PATH=$A/amber_linux/bin:$PATH'
    exit 1
  fi
done
echo "antechamber: $(command -v antechamber)"

for n in "$@"; do
  R=C$n
  python3 "$AQUI/preparar_substrato.py" "$PDB" "$n" || { echo "ERRO na pose de $R"; exit 1; }
  if ! antechamber -i ${R}_pose.sdf -fi mdl -o ${R}.mol2 -fo mol2 \
         -c bcc -nc -1 -at gaff2 -rn ${R} -s 0 -pf y > ${R}_antechamber.log 2>&1 \
     || [ ! -s ${R}.mol2 ]; then
    echo "ERRO: antechamber falhou para $R. Final do log (${R}_antechamber.log):"
    tail -n 20 ${R}_antechamber.log
    [ -f sqm.out ] && { echo "--- final do sqm.out ---"; tail -n 20 sqm.out; }
    exit 1
  fi
  [ -f sqm.out ] && mv sqm.out ${R}_sqm.out
  rm -f sqm.in sqm.pdb
  python3 "$AQUI/normalizar_carga_mol2.py" ${R}.mol2 -1 || exit 1
  parmchk2 -i ${R}.mol2 -f mol2 -o ${R}.frcmod -s gaff2 || { echo "ERRO no parmchk2 ($R)"; exit 1; }
  echo "$R pronto"
done
