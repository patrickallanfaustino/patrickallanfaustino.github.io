#!/usr/bin/env python3
"""Monta o arquivo de aguas cristalograficas (so os O) para o montar_sistema.py.

Uso:
  python3 juntar_aguas.py CRISTAL.pdb "709 710" saida.pdb [enterradas_notebook.pdb]

- Pega do cristal as aguas pedidas pelo numero (conformacao A se houver
  altloc). Sao as aguas do bolso distal, que o criterio de SASA do notebook
  descarta quando o bolso esta vazio (heme e substrato fora do calculo).
- Opcional: junta as aguas enterradas que o notebook v17 reteve
  (output_.../waters/proteina_com_aguas.pdb, so as linhas HOH).
- Descarta aguas do notebook a < 2,0 A de outra ja incluida (duplicata ou
  choque: O...O de agua real nunca fica abaixo de ~2,5 A).
"""
import sys
import numpy as np

cristal, ids, saida = sys.argv[1], {int(x) for x in sys.argv[2].split()}, sys.argv[3]
extra = sys.argv[4] if len(sys.argv) > 4 else None

def aguas(arq, filtro=lambda n: True):
    out = []
    for l in open(arq):
        if (l.startswith(("ATOM", "HETATM")) and l[17:20] in ("HOH", "WAT")
                and l[12:16].strip() == "O" and l[16] in " A" and filtro(int(l[22:26]))):
            out.append(np.array([float(l[30:38]), float(l[38:46]), float(l[46:54])]))
    return out

sel = aguas(cristal, lambda n: n in ids)
if len(sel) != len(ids):
    sys.exit(f"Achei {len(sel)} de {len(ids)} aguas pedidas em {cristal}")
todas, dup = list(sel), 0
if extra:
    for x in aguas(extra):
        if min(np.linalg.norm(x - y) for y in todas) < 2.0:
            dup += 1
        else:
            todas.append(x)
with open(saida, "w") as f:
    for i, x in enumerate(todas):
        f.write(f"HETATM{i + 1:5d}  O   HOH W{i + 1:4d}    {x[0]:8.3f}{x[1]:8.3f}{x[2]:8.3f}"
                f"  1.00  0.00           O\n")
    f.write("END\n")
print(f"{saida}: {len(sel)} do bolso + {len(todas) - len(sel)} do notebook "
      f"({dup} duplicadas/em choque descartadas)")
