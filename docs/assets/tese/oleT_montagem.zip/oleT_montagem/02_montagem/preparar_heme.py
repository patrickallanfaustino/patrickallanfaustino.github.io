#!/usr/bin/env python3
"""Separa proteina e heme, renumera o heme e (CPDI) posiciona o O ferrila.

Uso:  python3 preparar_heme.py protonated.pdb 4L40.pdb IC6|CPDI saida.pdb [85=HIE ...]

- Argumentos opcionais NUM=ESTADO trocam o nome de um residuo (ex.: 85=HIE
  para a variante da His85). Como os H sao removidos e o tleap os reconstroi
  pelo nome, isso basta: nao e preciso rodar o notebook de novo.

- Proteina: do protonated.pdb (notebook v17; estados pelo NOME do residuo).
- Heme: do 4L40.pdb original (HETATM HEM da cadeia A). O PDBFixer e o
  PDB2PQR nao movem atomos, entao os dois arquivos estao no mesmo referencial;
  o script confere pela distancia Fe-SG (4L40: ~2,3 A).

- Remove todos os H (o tleap reconstroi pelos templates: CYM/HIx pelo nome,
  HEM pela biblioteca do Shahrokh). Mesma filosofia do pdb2gmx -ignh.
- Renumera o HEM para (ultimo residuo da proteina + 1). O tleap numera os
  residuos em sequencia a partir do numero do PRIMEIRO residuo do arquivo e
  nao preserva saltos (ex.: HEM 501 vira 423 numa cadeia 4-422). Renumerar
  aqui faz o numero do arquivo coincidir com o indice do tleap.
- CPDI: O1 sobre a normal ao plano dos 4 N pirrolicos, do lado distal
  (oposto ao SG da Cys365), a 1,639 A do Fe (r0 de fe-oa no CPDI.frcmod).
  A normal, e nao o prolongamento S->Fe, porque no CPDI.frcmod o angulo
  SH-fe-oa tem constante 0 (nao atua) e quem orienta o O1 sao os angulos
  nc/nd-fe-oa (92,4 graus).
"""
import sys
import numpy as np

proteina, cristal, estado, saida = sys.argv[1], sys.argv[2], sys.argv[3].upper(), sys.argv[4]
TAUTOMEROS = {"HID", "HIE", "HIP"}
renomear = {}
for arg in sys.argv[5:]:
    num, novo = arg.split("=")
    assert novo in TAUTOMEROS, f"{arg}: so HID/HIE/HIP"
    renomear[int(num)] = novo
assert estado in ("IC6", "CPDI")
CYS_AXIAL = 365

def pesados(arq, filtro):
    out = []
    for l in open(arq):
        if not l.startswith(("ATOM", "HETATM")) or not filtro(l):
            continue
        el = (l[76:78].strip() or l[12:16].strip()[0]).upper()
        if el == "H" or l[16] not in (" ", "A"):
            continue
        out.append(l[:16] + " " + l[17:])           # remove altloc
    return out

AGUA_LIG = {"HOH", "WAT", "HEM", "DCR"}
prot = pesados(proteina, lambda l: l[17:20].strip() not in AGUA_LIG)
for num, novo in renomear.items():
    alvo = [l for l in prot if int(l[22:26]) == num]
    assert alvo and alvo[0][17:20] in TAUTOMEROS, f"residuo {num} nao e His"
    print(f"Residuo {num}: {alvo[0][17:20]} -> {novo}")
    prot = [l[:17] + novo + l[20:] if int(l[22:26]) == num else l for l in prot]
heme = pesados(cristal, lambda l: l[17:20] == "HEM" and l[21] == "A")
if len(heme) != 43:
    sys.exit(f"HEM da cadeia A com {len(heme)} atomos pesados (esperado 43)")

ultimo = max(int(l[22:26]) for l in prot)
n_heme = ultimo + 1
heme = ["ATOM  " + l[6:22] + f"{n_heme:4d}" + l[26:] for l in heme]
xyz = {l[12:16].strip(): np.array([float(l[30:38]), float(l[38:46]), float(l[46:54])])
       for l in heme}
sg = next(np.array([float(l[30:38]), float(l[38:46]), float(l[46:54])])
          for l in prot if int(l[22:26]) == CYS_AXIAL and l[12:16].strip() == "SG")
fe = xyz["FE"]
d_fes = np.linalg.norm(fe - sg)
print(f"Fe-SG (heme do cristal x Cys365 da proteina protonada): {d_fes:.3f} A")
if not 2.0 < d_fes < 2.6:
    sys.exit("Fe-SG fora de 2,0-2,6 A: proteina e cristal nao estao no mesmo referencial?")

if estado == "CPDI" and "O1" not in xyz:
    N = np.array([xyz[k] for k in ("NA", "NB", "NC", "ND")])
    centro = N.mean(axis=0)
    _, _, vt = np.linalg.svd(N - centro)
    normal = vt[2] / np.linalg.norm(vt[2])
    if np.dot(normal, sg - fe) > 0:                 # aponta para o lado distal
        normal = -normal
    o1 = fe + 1.639 * normal
    ang = np.degrees(np.arccos(np.dot(sg - fe, o1 - fe) /
                               (np.linalg.norm(sg - fe) * np.linalg.norm(o1 - fe))))
    print(f"O1 posicionado: Fe-O1 1.639 A, S-Fe-O1 {ang:.1f} graus")
    base = heme[-1]
    heme.append(base[:12] + " O1 " + base[16:30] +
                f"{o1[0]:8.3f}{o1[1]:8.3f}{o1[2]:8.3f}" + base[54:76] + " O\n")

with open(saida, "w") as f:
    f.writelines(prot); f.write("TER\n")
    f.writelines(heme); f.write("TER\nEND\n")
print(f"{saida}: proteina {len(prot)} atomos pesados, HEM {len(heme)} atomos, "
      f"HEM renumerado para {n_heme}")
