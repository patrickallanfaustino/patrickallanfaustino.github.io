#!/usr/bin/env python3
"""Monta o sistema OleT_JE (proteina + heme Shahrokh + substrato) no tleap,
com ions por SLTCAP, e converte para GROMACS com o acpype.

"O Amber monta, o GROMACS roda": todos os parametros entram num unico
prmtop; o acpype (amb2gmx) escreve o .top com o CMAP do ff19SB por residuo.

Uso:  python3 montar_sistema.py            (valores da secao PARAMETROS)
      python3 montar_sistema.py --estado CPDI --substrato C14 \
          --pdb proteina_heme_CPDI_h85HID.pdb --aguas aguas_4L40.pdb --rotulo 4L40_h85HID
      (cada opcao omitida usa o valor da secao PARAMETROS; --substrato none = apo)
Saida em DIR_SAIDA: tleap_*.in/.log, soluto.prmtop, sistema.prmtop/.inpcrd,
      sistema.amb2gmx/ (top, gro, posre_*.itp) e relatorio_montagem.json
"""
import json, math, shutil, subprocess, sys
from collections import Counter
from pathlib import Path

# =========================== PARAMETROS ====================================
ESTADO        = "IC6"                  # "IC6" | "CPDI"
PDB_PROTEINA  = "proteina_heme_IC6.pdb"  # saida do preparar_heme.py
SUBSTRATO     = "C14"                  # None = sem substrato; senao o nome do residuo
ROTULO        = "4L40"                 # identifica estrutura/variante no nome da pasta
AGUAS_CRIST   = None                   # PDB so com os O das aguas enterradas (notebook v17,
                                       # waters/proteina_com_aguas.pdb filtrado); None = sem
DIR_PARAM     = "../01_parametros"     # mol2/frcmod do Shahrokh (+ CPDI_errata.frcmod)
DIR_SUBSTRATO = "../03_substrato"      # <SUBSTRATO>.mol2 e <SUBSTRATO>.frcmod
CAMPO         = "ff19SB"               # "ff19SB" (agua OPC) | "ff14SB" (agua TIP3P)
DIST_CAIXA_A  = 12.0                   # solvateOct ... iso: distancia minima soluto-borda
CONC_SAL_M    = 0.30                   # NaCl, mol/L (SLTCAP)
RES_CYS       = 365                    # indice no tleap = numero no PDB (cadeia 4-422)
RES_HEM       = 423                    # preparar_heme.py renumera o HEM para ultimo+1
OFFSET_RESNR  = 3                      # acpype numera a partir de 1; 4L40 comeca na Leu4
# ===========================================================================

import argparse
_ap = argparse.ArgumentParser(description="Monta o sistema OleT_JE no tleap e converte para GROMACS")
_ap.add_argument("--estado", choices=["IC6", "CPDI"])
_ap.add_argument("--pdb", help="saida do preparar_heme.py")
_ap.add_argument("--substrato", help="C8 ... C20, ou none (apo)")
_ap.add_argument("--aguas", help="PDB do juntar_aguas.py, ou none")
_ap.add_argument("--rotulo")
_a = _ap.parse_args()
ESTADO = _a.estado or ESTADO
PDB_PROTEINA = _a.pdb or PDB_PROTEINA
if _a.substrato:
    SUBSTRATO = None if _a.substrato.lower() == "none" else _a.substrato
if _a.aguas:
    AGUAS_CRIST = None if _a.aguas.lower() == "none" else _a.aguas
ROTULO = _a.rotulo or ROTULO
DIR_SAIDA = f"sistema_{ROTULO}_{ESTADO}_{SUBSTRATO or 'apo'}"
if ESTADO == "CPDI" and SUBSTRATO is None:
    sys.exit("CPDI sem substrato nao tem sentido fisico (Composto I se forma com substrato ligado)")

AGUA = {"ff19SB": ("leaprc.water.opc", "OPCBOX"),
        "ff14SB": ("leaprc.water.tip3p", "TIP3PBOX")}[CAMPO]
M_AGUA = 55.34        # mol/L de agua pura a 25 C (997 g/L / 18.015 g/mol)

here = Path.cwd()
# scripts auxiliares de 04_gromacs: confere ANTES dos ~3 min de tleap
_aux = Path(__file__).resolve().parent.parent / "04_gromacs"
_faltam = [f for f in ("renumerar_residuos.py", "gerar_posres.py") if not (_aux / f).exists()]
if _faltam:
    sys.exit(f"ERRO: faltam em {_aux}: {', '.join(_faltam)}. "
             "Restaure do oleT_montagem.zip (pasta 04_gromacs) antes de montar.")
saida = Path(DIR_SAIDA); saida.mkdir(exist_ok=True)
prm = Path(DIR_PARAM).resolve()
frcmods = [prm / f"{ESTADO}.frcmod"] + ([prm / "CPDI_errata.frcmod"] if ESTADO == "CPDI" else [])
for f in frcmods + [prm / f"{ESTADO}_HEM.mol2", prm / f"{ESTADO}_CYP.mol2", Path(PDB_PROTEINA)]:
    if not f.exists():
        sys.exit(f"Arquivo ausente: {f}")

def cargas_mol2(arq):
    linhas, dentro = [], False
    for l in Path(arq).read_text().splitlines():
        if l.startswith("@<TRIPOS>ATOM"):
            dentro = True; continue
        if l.startswith("@<TRIPOS>"):
            dentro = False; continue
        if dentro and l.strip():
            c = l.split(); linhas.append((c[1], float(c[8])))
    return linhas

cyp = cargas_mol2(prm / f"{ESTADO}_CYP.mol2")
set_cargas = "\n".join(f"set prot.{RES_CYS}.{n} charge {q:.4f}" for n, q in cyp)

def script_tleap(solvatar, ions=None):
    s = [f"source leaprc.protein.{CAMPO}", f"source {AGUA[0]}", "source leaprc.gaff2",
         'addAtomTypes { { "fe" "Fe" "sp3" } { "oa" "O" "sp2" } }']
    s += [f"loadamberparams {f}" for f in frcmods]
    s += [f"HEM = loadmol2 {prm / f'{ESTADO}_HEM.mol2'}"]
    if SUBSTRATO:
        d = Path(DIR_SUBSTRATO).resolve()
        s += [f"loadamberparams {d / (SUBSTRATO + '.frcmod')}",
              f"LIG = loadmol2 {d / (SUBSTRATO + '.mol2')}"]
    if AGUAS_CRIST:
        s += [f"AGU = loadpdb {Path(AGUAS_CRIST).resolve()}"]
    s += [f"prot = loadpdb {Path(PDB_PROTEINA).resolve()}",
          f"desc prot.{RES_CYS}", f"desc prot.{RES_HEM}",
          f"bond prot.{RES_CYS}.SG prot.{RES_HEM}.FE",
          "# cargas da CYP de Shahrokh sobre a CYM (tipos e CMAP do campo de forca)",
          set_cargas, "charge prot"]
    partes = "prot" + (" LIG" if SUBSTRATO else "") + (" AGU" if AGUAS_CRIST else "")
    s += [f"mol = combine {{ {partes} }}", "charge mol"]
    if not solvatar:
        s += ["saveamberparm mol soluto.prmtop soluto.inpcrd", "savepdb mol soluto.pdb"]
    else:
        s += [f"solvateOct mol {AGUA[1]} {DIST_CAIXA_A} iso"]
        if ions:
            # duas chamadas: com os dois ions numa so, o tleap os intercala
            # (Na, Cl, Na...) e o [ molecules ] do acpype (NA+ em bloco, CL- em
            # bloco) deixa de corresponder ao .gro
            s += [f"addIonsRand mol Na+ {ions[0]} 6.0", f"addIonsRand mol Cl- {ions[1]} 6.0",
                  "charge mol",
                  "saveamberparm mol sistema.prmtop sistema.inpcrd", "savepdb mol sistema.pdb"]
        else:
            s += ["saveamberparm mol passo1.prmtop passo1.inpcrd"]
    return "\n".join(s + ["quit"]) + "\n"

def rodar_tleap(nome, texto):
    (saida / f"{nome}.in").write_text(texto)
    with open(saida / f"{nome}.log", "w") as log:
        subprocess.run(["tleap", "-f", f"{nome}.in"], cwd=saida, stdout=log,
                       stderr=subprocess.STDOUT, check=True)
    log = (saida / f"{nome}.log").read_text()
    linha = [l for l in log.splitlines() if l.startswith("Exiting LEaP")][-1]
    if "Errors = 0" not in linha:
        sys.exit(f"tleap ({nome}) terminou com erro -> {saida / (nome + '.log')}\n{linha}")
    return log

def carga_total(prmtop):
    import parmed as pmd
    s = pmd.load_file(str(saida / prmtop))
    return s, sum(a.charge for a in s.atoms)

import parmed as pmd                                     # noqa: E402

def conferir_ordem(top, gro):
    """Cada atomo do .gro tem de ter o mesmo nome que a posicao correspondente
    do .top expandido pelo [ molecules ]. O grompp so AVISA quando nao bate
    (e usa o .top): com -maxwarn, ions trocados passariam em silencio."""
    nomes, secao, atual, esperando, ordem = {}, None, None, False, []
    for l in Path(top).read_text().splitlines():
        s = l.split(";")[0].strip()
        if not s or s.startswith("#"):
            continue
        if s.startswith("["):
            secao = s.strip("[] ").lower(); esperando = secao == "moleculetype"; continue
        if esperando:
            atual, esperando = s.split()[0], False; nomes[atual] = []; continue
        if secao == "atoms":
            nomes[atual].append(s.split()[4])
        elif secao == "molecules":
            ordem.append((s.split()[0], int(s.split()[1])))
    esperado = [n for m, k in ordem for _ in range(k) for n in nomes[m]]
    G = Path(gro).read_text().splitlines()
    lidos = [l[10:15].strip() for l in G[2:2 + int(G[1])]]
    ruins = [i for i, (a, b) in enumerate(zip(esperado, lidos)) if a != b]
    if len(esperado) != len(lidos) or ruins:
        sys.exit(f"ERRO: .gro e .top divergem ({len(ruins)} nomes; 1o no atomo "
                 f"{ruins[0] + 1 if ruins else '-'}). Nao prossiga.")
    print(f"    ordem .gro x .top conferida: {len(lidos)} atomos identicos")

# ---- 1. soluto (sem solvente): carga por componente e ligacoes do Fe ----
log = rodar_tleap("tleap_soluto", script_tleap(False))
sol, q_sol = carga_total("soluto.prmtop")
q_prot = sum(a.charge for a in sol.atoms if a.residue.name != SUBSTRATO)
q_lig = q_sol - q_prot
res_hem = [r for r in sol.residues if r.name == "HEM"]
res_cys = [r for r in sol.residues if r.name == "CYM"]
assert len(res_hem) == 1 and len(res_cys) == 1, "esperado 1 HEM e 1 CYM"
q_sitio = sum(a.charge for r in res_hem + res_cys for a in r.atoms)
fe = next(a for a in res_hem[0].atoms if a.name == "FE")
ligacoes_fe = sorted((b.atom1 if b.atom2 is fe else b.atom2).name + f" {b.type.req:.3f}"
                     for b in fe.bonds)
for rotulo, q in (("proteina+heme", q_prot), ("HEM+CYM", q_sitio), ("substrato", q_lig)):
    if abs(q - round(q)) > 2e-3:
        sys.exit(f"Carga nao inteira em {rotulo}: {q:+.4f}")
Q = round(q_sol)
print(f"[1] soluto: proteina+heme {q_prot:+.4f} | HEM+CYM {q_sitio:+.4f} | "
      f"substrato {q_lig:+.4f} | total {Q:+d}")
print(f"    ligacoes do Fe (A): {', '.join(ligacoes_fe)}")
if AGUAS_CRIST:
    # agua cristalografica em choque com o soluto (ex.: W709 do 4L40 fica a
    # 1,9 A do O ferrila no CPDI, que ocupa o mesmo sitio)
    import numpy as np
    s_ = pmd.load_file(str(saida / "soluto.prmtop"), str(saida / "soluto.inpcrd"))
    x_ = np.array(s_.coordinates)
    iw = [a.idx for a in s_.atoms if a.residue.name == "WAT" and a.name == "O"]
    ip = [a.idx for a in s_.atoms if a.residue.name != "WAT" and a.element > 1]
    for i in iw:
        d = np.linalg.norm(x_[ip] - x_[i], axis=1)
        j = ip[int(d.argmin())]
        if d.min() < 2.5:
            a = s_.atoms[j]
            sys.exit(f"Agua cristalografica a {d.min():.2f} A de {a.residue.name}:{a.name}"
                     f" ({x_[i].round(2)}). Retire-a do arquivo de aguas.")
n_cmap_tipos = len({id(c.type) for c in sol.cmaps})
if CAMPO == "ff19SB":
    print(f"    CMAP: {len(sol.cmaps)} termos, {n_cmap_tipos} tipos (ff19SB: 14)")
    assert n_cmap_tipos == 14, "ff19SB deveria ter 14 CMAPs distintos"

# ---- 2. passo 1 de solvatacao: contar aguas ----
log = rodar_tleap("tleap_passo1", script_tleap(True))
p1 = pmd.load_file(str(saida / "passo1.prmtop"))
n_cris = 0
if AGUAS_CRIST:
    O_cris = [[float(l[30:38]), float(l[38:46]), float(l[46:54])]
              for l in Path(AGUAS_CRIST).read_text().splitlines()
              if l.startswith(("ATOM", "HETATM")) and l[12:16].strip() == "O"]
    n_cris = len(O_cris)
# SLTCAP usa a agua do bulk: as enterradas nao solvatam os ions
n_agua = sum(1 for r in p1.residues if r.name == "WAT") - n_cris

# ---- 3. SLTCAP (Schmit et al., JCTC 2018) ----
N0 = CONC_SAL_M * n_agua / M_AGUA
x = Q / (2 * N0)
n_pos = round(N0 * (math.sqrt(1 + x * x) - x))
n_neg = n_pos + Q                                        # neutralidade exata
print(f"[2] {n_agua} aguas | N0 = {N0:.2f} | Na+ {n_pos} | Cl- {n_neg}")

# ---- 4. sistema final ----
def aguas_perdidas():
    """Quantas aguas cristalograficas o addIonsRand trocou por ion (0 = todas la).
    O solvateOct translada e gira o soluto, e o addIonsRand insere os ions antes
    das aguas (a ordem muda): superpoe-se o heme (Kabsch) e procura-se uma agua
    a < 0,01 A de cada posicao original."""
    import numpy as np
    s_ = pmd.load_file(str(saida / "sistema.prmtop"), str(saida / "sistema.inpcrd"))
    r_ = pmd.load_file(str(saida / "soluto.prmtop"), str(saida / "soluto.inpcrd"))
    xs, xr = np.array(s_.coordinates), np.array(r_.coordinates)
    hs = [a.idx for a in s_.atoms if a.residue.name == "HEM"]
    hr = [a.idx for a in r_.atoms if a.residue.name == "HEM"]
    A, B = xr[hr] - xr[hr].mean(0), xs[hs] - xs[hs].mean(0)
    U, _, Vt = np.linalg.svd(B.T @ A)
    R = U @ np.diag([1, 1, np.sign(np.linalg.det(U @ Vt))]) @ Vt
    xs = (xs - xs[hs].mean(0)) @ R + xr[hr].mean(0)
    O_sis = xs[[a.idx for a in s_.atoms if a.residue.name == "WAT" and a.name == "O"]]
    O_ref = [xr[a.idx] for a in r_.atoms if a.residue.name == "WAT" and a.name == "O"]
    assert len(O_ref) == n_cris, "numero de aguas enterradas no soluto != arquivo"
    return sum(np.linalg.norm(O_sis - o, axis=1).min() >= 0.01 for o in O_ref)

# O addIonsRand troca aguas aleatorias por ions e nao distingue as
# cristalograficas; com ~20 delas entre ~27 mil, ~1 montagem em 5 perde uma.
# A posicao dos ions e aleatoria de qualquer forma: repete-se ate preservar todas.
TENTATIVAS = 10
for tentativa in range(1, TENTATIVAS + 1):
    log = rodar_tleap("tleap_sistema", script_tleap(True, (n_pos, n_neg)))
    sis, q_sis = carga_total("sistema.prmtop")
    perdidas = aguas_perdidas() if AGUAS_CRIST else 0
    if perdidas == 0:
        break
    print(f"    tentativa {tentativa}: {perdidas} agua(s) enterrada(s) trocada(s) por ion; repetindo")
else:
    sys.exit(f"ERRO: aguas enterradas trocadas por ion em {TENTATIVAS} tentativas seguidas")
cont = Counter(r.name for r in sis.residues)
print(f"[3] sistema: {len(sis.atoms)} atomos | carga {q_sis:+.5f} | "
      f"WAT {cont['WAT']} Na+ {cont['Na+']} Cl- {cont['Cl-']}")
if AGUAS_CRIST:
    print(f"    {n_cris} aguas enterradas preservadas nas posicoes cristalograficas"
          + (f" (tentativa {tentativa})" if tentativa > 1 else ""))
for f in ("passo1.prmtop", "passo1.inpcrd"):
    (saida / f).unlink()

# ---- 5. conversao para GROMACS ----
subprocess.run(["acpype", "-p", "sistema.prmtop", "-x", "sistema.inpcrd", "-b", "sistema", "-S"],
               cwd=saida, check=True, stdout=open(saida / "acpype.log", "w"),
               stderr=subprocess.STDOUT)
gdir = saida / "sistema.amb2gmx"
scripts = Path(__file__).resolve().parent.parent / "04_gromacs"
subprocess.run([sys.executable, scripts / "renumerar_residuos.py", "sistema_GMX.top",
                "sistema_GMX.gro", str(OFFSET_RESNR)], cwd=gdir, check=True)
subprocess.run([sys.executable, scripts / "gerar_posres.py", "sistema_GMX.top"],
               cwd=gdir, check=True)
top = (gdir / "sistema_GMX.top").read_text()
conferir_ordem(gdir / "sistema_GMX.top", gdir / "sistema_GMX.gro")
n_cmaptypes = sum(1 for l in top.splitlines() if l.startswith("C-*"))
print(f"[4] GROMACS: {gdir}/sistema_GMX.top | cmaptypes por residuo: {n_cmaptypes}")

relatorio = {
    "rotulo": ROTULO, "estado": ESTADO, "campo": CAMPO, "aguas_cristal_arquivo": AGUAS_CRIST, "agua": AGUA[0], "substrato": SUBSTRATO,
    "pdb_entrada": str(PDB_PROTEINA), "carga_proteina_heme": round(q_prot, 4),
    "carga_HEM_CYM": round(q_sitio, 4), "carga_substrato": round(q_lig, 4),
    "carga_soluto": Q, "ligacoes_Fe_r0_A": ligacoes_fe,
    "cmap_termos": len(sol.cmaps), "cmap_tipos_prmtop": n_cmap_tipos,
    "cmaptypes_top": n_cmaptypes, "aguas_bulk_passo1": n_agua, "aguas_enterradas": n_cris,
    "tentativas_ions": tentativa,
    "sltcap": {"c0_M": CONC_SAL_M, "N0": round(N0, 3), "Na+": n_pos, "Cl-": n_neg},
    "sistema": {"atomos": len(sis.atoms), "WAT": cont["WAT"], "carga": round(q_sis, 5),
                "caixa_A_graus": [round(v, 4) for v in sis.box]},
    "versoes": {"parmed": pmd.__version__,
                "acpype": subprocess.run(["acpype", "--version"], capture_output=True,
                                         text=True).stdout.strip()[-60:]},
}
(saida / "relatorio_montagem.json").write_text(json.dumps(relatorio, indent=2))
print(f"Relatorio -> {saida / 'relatorio_montagem.json'}")
