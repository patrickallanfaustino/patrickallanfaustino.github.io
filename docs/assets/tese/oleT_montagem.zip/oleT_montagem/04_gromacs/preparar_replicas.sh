#!/usr/bin/env bash
# Cria rep1..repN com copias das mdp de NVT/NPT/MD, cada replica com sementes
# proprias (gen-seed no nvt1; ld-seed em todas as etapas, usado pelo V-rescale).
# Semente da replica r = r*1000000 + semente original da mdp (unica por etapa).
# Uso (dentro de sistema_*/sistema.amb2gmx): bash preparar_replicas.sh /caminho/mdp 5
set -euo pipefail
M=$1; N=$2
ETAPAS="nvt1_heat nvt2_hold npt1 npt2 npt3 npt4 md"
echo "replica etapa gen-seed ld-seed" > sementes.tsv
for r in $(seq 1 "$N"); do
  mkdir -p rep$r
  for e in $ETAPAS; do
    awk -v r="$r" '
      /^[ \t]*(gen[-_]seed|ld[-_]seed)[ \t]*=/ {
        split($0, a, "="); v = a[2]; sub(/;.*/, "", v); gsub(/[ \t]/, "", v)
        nome = a[1]; gsub(/[ \t]/, "", nome)
        printf "%-23s = %d\n", nome, r * 1000000 + v; next }
      { print }' "$M/$e.mdp" > rep$r/$e.mdp
    gs=$(awk -F= '/^[ \t]*gen[-_]seed/{gsub(/[ \t]/,"",$2); print $2}' rep$r/$e.mdp)
    ls=$(awk -F= '/^[ \t]*ld[-_]seed/{gsub(/[ \t]/,"",$2); print $2}' rep$r/$e.mdp)
    echo "$r $e ${gs:--} ${ls:--}" >> sementes.tsv
  done
done
cat sementes.tsv
