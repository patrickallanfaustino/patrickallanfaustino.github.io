#!/usr/bin/env python3
"""Devolve a numeracao do PDB (4L40) ao soluto no .top e no .gro do acpype.

O prmtop -> GROMACS numera os residuos a partir de 1. No 4L40 a cadeia
comeca na Leu4, entao Cys365 viraria 362 e o heme 420. Este script soma
OFFSET aos residuos das moleculetypes do soluto (proteina+heme e substrato)
no .top e aos mesmos atomos no .gro, para que resnr no gmx select, nos
indices e nos graficos seja o numero da literatura (Cys365, HEM 423,
substrato 424).

Uso: python3 renumerar_residuos.py topol.top conf.gro OFFSET [moltype ...]
     sem moltype: a que contem o HEM e as que vem antes dos ions no [ molecules ].
"""
import sys
from pathlib import Path

top, gro, offset = Path(sys.argv[1]), Path(sys.argv[2]), int(sys.argv[3])
pedidas = sys.argv[4:]
IONS_AGUA = {"NA+", "CL-", "NA", "CL", "WAT", "SOL", "HOH", "K+"}

linhas = top.read_text().splitlines()
# 1. moleculetypes: nome -> residuos presentes e numero de atomos
secao, atual, esperando, info, ordem = None, None, False, {}, []
for l in linhas:
    s = l.split(";")[0].strip()
    if not s or s.startswith("#"):
        continue
    if s.startswith("["):
        secao = s.strip("[] ").lower(); esperando = secao == "moleculetype"; continue
    if esperando:
        atual, esperando = s.split()[0], False
        info[atual] = {"res": set(), "n": 0}; continue
    if secao == "atoms" and atual:
        info[atual]["res"].add(s.split()[3]); info[atual]["n"] += 1
    elif secao == "molecules":
        ordem.append((s.split()[0], int(s.split()[1])))

if not pedidas:
    pedidas = [m for m, _ in ordem if m not in IONS_AGUA]
alvo = set(pedidas)
# os alvos tem de ser as primeiras moleculas do sistema (1 copia cada)
n_gro = 0
for m, k in ordem:
    if m not in alvo:
        break
    n_gro += info[m]["n"] * k
assert n_gro == sum(info[m]["n"] for m in alvo), "soluto deve vir primeiro no [ molecules ]"

# 2. .top
saida, secao, atual, esperando = [], None, None, False
for l in linhas:
    s = l.split(";")[0].strip()
    if s.startswith("[") :
        secao = s.strip("[] ").lower(); esperando = secao == "moleculetype"
    elif esperando and s and not s.startswith("#"):
        atual, esperando = s.split()[0], False
    elif secao == "atoms" and atual in alvo and s and not s.startswith("#"):
        c = s.split()
        c[2] = str(int(c[2]) + offset)          # nr type RESNR resname name cgnr q m
        com = "  ;" + l.split(";", 1)[1] if ";" in l else ""
        l = "{:>6s} {:>6s} {:>6s} {:>6s} {:>6s} {:>6s} {:>13s} {:>12s}".format(*c[:8]) + com
    saida.append(l)
top.write_text("\n".join(saida) + "\n")

# 3. .gro (o substrato continua a numeracao do .top: o acpype numera em sequencia)
G = gro.read_text().splitlines()
for i in range(2, 2 + n_gro):
    G[i] = f"{int(G[i][0:5]) + offset:5d}" + G[i][5:]
gro.write_text("\n".join(G) + "\n")
print(f"{', '.join(pedidas)}: {n_gro} atomos renumerados (+{offset}) em {top.name} e {gro.name}")
