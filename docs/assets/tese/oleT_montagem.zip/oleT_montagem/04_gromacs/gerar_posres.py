#!/usr/bin/env python3
"""Gera as restricoes posicionais e as inclui no .top, na moleculetype certa.

Grupos (atomos pesados; o valor da constante vem do define do .mdp):
  POSRES_FC_BB   cadeia principal da proteina (N, CA, C, O)
  POSRES_FC_SC   cadeias laterais da proteina
  POSRES_FC_LIG  heme (todos os pesados, Fe incluido) e substrato
Indices sao relativos a cada moleculetype, como o GROMACS exige.

Uso: python3 gerar_posres.py topol.top [soluto] [substrato ...]
     (padrao: soluto = a moleculetype que contem o HEM;
      substratos = moleculetypes chamadas C8, C10, ... C20)
"""
import sys, re
from pathlib import Path

top = Path(sys.argv[1])
soluto = sys.argv[2] if len(sys.argv) > 2 else None
substratos = set(sys.argv[3:]) or None
COFATORES = {"HEM"}
BB = {"N", "CA", "C", "O", "OXT"}

def ler_moleculetypes(linhas):
    mols, secao, atual, esperando = {}, None, None, False
    for i, l in enumerate(linhas):
        s = l.split(";")[0].strip()
        if s.startswith("#"):                      # diretivas do pre-processador
            continue
        if s.startswith("["):
            secao = s.strip("[] ").lower()
            esperando = secao == "moleculetype"
            if secao == "moleculetype" and atual:
                mols[atual]["fim"] = i
        elif esperando and s:
            atual, esperando = s.split()[0], False
            mols[atual] = {"atomos": [], "fim": None}
        elif secao == "atoms" and s and atual:
            c = s.split()
            mols[atual]["atomos"].append((int(c[0]), c[3], c[4], float(c[7])))
        elif secao == "system" and atual and mols[atual]["fim"] is None:
            mols[atual]["fim"] = i
    return mols

def escrever_itp(nome, macro, indices):
    txt = [f"; {nome}: {len(indices)} atomos, constante {macro} (kJ mol-1 nm-2)",
           "[ position_restraints ]", ";  ai  funct  fcx  fcy  fcz"]
    txt += [f"{i:6d}     1  {macro}  {macro}  {macro}" for i in indices]
    Path(nome).write_text("\n".join(txt) + "\n")

linhas = top.read_text().splitlines()
mols = ler_moleculetypes(linhas)
if soluto is None:
    soluto = next(m for m, d in mols.items() if any(r == "HEM" for _, r, _, _ in d["atomos"]))
if substratos is None:
    substratos = {m for m in mols if re.fullmatch(r"C\d{1,2}", m)}

inserir = {}                                       # linha de insercao -> includes
a = mols[soluto]["atomos"]
pesado = lambda m: m > 1.5
bb  = [n for n, r, at, m in a if pesado(m) and r not in COFATORES and at in BB]
sc  = [n for n, r, at, m in a if pesado(m) and r not in COFATORES and at not in BB]
cof = [n for n, r, at, m in a if pesado(m) and r in COFATORES]
escrever_itp("posre_bb.itp", "POSRES_FC_BB", bb)
escrever_itp("posre_sc.itp", "POSRES_FC_SC", sc)
escrever_itp("posre_heme.itp", "POSRES_FC_LIG", cof)
inserir[mols[soluto]["fim"]] = ["posre_bb.itp", "posre_sc.itp", "posre_heme.itp"]
print(f"{soluto}: BB {len(bb)} | SC {len(sc)} | heme {len(cof)}")

for s in sorted(substratos):
    lig = [n for n, r, at, m in mols[s]["atomos"] if pesado(m)]
    nome = f"posre_{s}.itp"
    escrever_itp(nome, "POSRES_FC_LIG", lig)
    inserir[mols[s]["fim"]] = [nome]
    print(f"{s}: {len(lig)} atomos pesados")

saida = []
for i, l in enumerate(linhas):
    if i in inserir:
        saida += ["#ifdef POSRES"] + [f'#include "{f}"' for f in inserir[i]] + ["#endif", ""]
    saida.append(l)
top.write_text("\n".join(saida) + "\n")
print(f"includes inseridos em {top.name}")
