#!/usr/bin/env python3
"""Compara as energias ligadas Amber (prmtop, via OpenMM) x GROMACS (rerun).

Termos ligados nao dependem de cutoff, PME nem caixa: se a conversao estiver
certa, batem na 4a-5a casa. E o teste que pegaria o CMAP colapsado do ParmEd.

1) GROMACS (mesmas coordenadas do .gro gerado pelo acpype):
     gmx grompp -f rerun.mdp -c sistema_GMX.gro -p sistema_GMX.top -o rerun.tpr
     gmx mdrun -s rerun.tpr -rerun sistema_GMX.gro -deffnm rerun
     printf "Bond\\nAngle\\nProper-Dih.\\nPer.-Imp.-Dih.\\nCMAP-Dih.\\n\\n" | \\
         gmx energy -f rerun.edr -o rerun_ligadas.xvg
2) python3 validar_energias.py sistema.prmtop sistema_GMX.gro rerun_ligadas.xvg

As coordenadas do lado Amber saem do MESMO .gro (precisao de 0,001 nm):
com o .inpcrd (1e-7 A) so o arredondamento ja desloca a energia de ligacao
em ~8%. Tanto faz o .gro antes ou depois do renumerar_residuos.py: a
renumeracao nao altera coordenadas nem a ordem dos atomos.

rerun.mdp minimo: integrator=md, nsteps=0, cutoff-scheme=Verlet,
coulombtype=PME, constraints=none (o rerun nao aplica restricoes; sem
isso o grompp converte ligacoes com H em constraints e a energia Bond cai).
"""
import sys
import openmm as mm, openmm.app as app, openmm.unit as u

prmtop, inpcrd = sys.argv[1], sys.argv[2]          # .inpcrd ou .gro
xvg = sys.argv[3] if len(sys.argv) > 3 else None

prm = app.AmberPrmtopFile(prmtop)
crd = app.GromacsGroFile(inpcrd) if inpcrd.endswith(".gro") else app.AmberInpcrdFile(inpcrd)
sis = prm.createSystem(nonbondedMethod=app.NoCutoff, constraints=None, rigidWater=True)
# O prmtop liga o sitio extra da agua de 4 sitios (EP/EPW) ao O; no OpenMM essa
# ligacao vira um termo harmonico, embora o EP seja sitio virtual nos dois
# programas (no GROMACS, [ virtual_sites3 ], sem energia). Zera-se esse termo.
for f in sis.getForces():
    if isinstance(f, mm.HarmonicBondForce):
        for i in range(f.getNumBonds()):
            a, b, r0, k = f.getBondParameters(i)
            if sis.isVirtualSite(a) or sis.isVirtualSite(b) or \
               sis.getParticleMass(a).value_in_unit(u.dalton) == 0 or \
               sis.getParticleMass(b).value_in_unit(u.dalton) == 0:
                f.setBondParameters(i, a, b, r0, 0.0)
grupos = {"HarmonicBondForce": 1, "HarmonicAngleForce": 2,
          "PeriodicTorsionForce": 3, "CMAPTorsionForce": 4}
for f in sis.getForces():
    f.setForceGroup(grupos.get(f.__class__.__name__, 0))
ctx = mm.Context(sis, mm.VerletIntegrator(1e-3), mm.Platform.getPlatformByName("CPU"))
ctx.setPositions(crd.positions)
ref = {n: ctx.getState(getEnergy=True, groups={g}).getPotentialEnergy()
           .value_in_unit(u.kilojoule_per_mole) for n, g in grupos.items()}
amber = {"Bond": ref["HarmonicBondForce"], "Angle": ref["HarmonicAngleForce"],
         "Torsoes (proprias+improprias)": ref["PeriodicTorsionForce"],
         "CMAP": ref["CMAPTorsionForce"]}

if not xvg:
    for k, v in amber.items():
        print(f"{k:32s} {v:16.4f} kJ/mol")
    sys.exit(0)

legendas, valores = [], None
for l in open(xvg):
    if l.startswith("@ s") and "legend" in l:
        legendas.append(l.split('"')[1])
    elif l.strip() and l[0] not in "#@":
        valores = [float(v) for v in l.split()[1:]]
        break
g = dict(zip(legendas, valores))
gmx = {"Bond": g.get("Bond"), "Angle": g.get("Angle"),
       "Torsoes (proprias+improprias)": g.get("Proper Dih.", 0) + g.get("Per. Imp. Dih.", 0),
       "CMAP": g.get("CMAP Dih.")}
print(f"{'termo':32s} {'Amber/OpenMM':>14s} {'GROMACS':>14s} {'desvio rel.':>12s}")
ok = True
for k in amber:
    a, b = amber[k], gmx[k]
    if b is None:
        print(f"{k:32s} {a:14.3f} {'ausente':>14s}"); ok = False; continue
    d = abs(a - b) / max(abs(a), 1e-9)
    ok &= d < 1e-4
    print(f"{k:32s} {a:14.3f} {b:14.3f} {d:12.2e}")
print("OK: conversao consistente" if ok else "FALHOU: desvio > 1e-4 em algum termo")
